import os, discord
from discord.ext import commands

token = input("Enter token: ")
client = commands.Bot(command_prefix=commands.when_mentioned_or("$"))
os.system('cls')
os.system(f'-9wand pressure')
os.system(f'mode 100,25')




@client.event
async def on_ready():
  print(f""" \u001b[31m

  
██████╗░███████╗░█████╗░████████╗██╗░░██╗
██╔══██╗██╔════╝██╔══██╗╚══██╔══╝██║░░██║
██║░░██║█████╗░░███████║░░░██║░░░███████║
██║░░██║██╔══╝░░██╔══██║░░░██║░░░██╔══██║
██████╔╝███████╗██║░░██║░░░██║░░░██║░░██║
╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝ DEATH ☆ ᴺᴼᴿᵀᴴ ᵂᴼᴿᴸᴰ#1211 runs you .ggbrixton
""")



@client.event
async def on_message(message):
    channel = message.channel
    if message.content.endswith('nope ur getting chat packed'):

        await message.channel.send ('LOL SON ALREADY TIRED')
        await message.channel.send ('FOCUS ON OUTLASTING A GOD')
        await message.channel.send ('UR SO ASS')
        await message.channel.send ('FOCUS FAGGOT')
        await message.channel.send ('U CANT PRESSURE A ABSOLUTE GOD')
        await message.channel.send ('TYPE FASTER SON UR SO ASS')
        await message.channel.send ('UR SHIT')
        await message.channel.send ('LITTLE 12 HOUR GOBLIN')
        await message.channel.send ('LOLO')
        await message.channel.send ('LOOL')
        await message.channel.send ('OLOL')
        await message.channel.send ('LOLO')
        await message.channel.send ('DONT STOP')
        await message.channel.send ('KEEP CHAT MOVING FUCK BOY')
        await message.channel.send ('HOPEFULLY YOU CAN LAST 100 HOURS FAGGOT')
        await message.channel.send ('YOU WOULD BE ASS AT PRESSURING TO LOLOLOL')
        await message.channel.send ('HOLY FUCK UR ASS')
        await message.channel.send ('IM FLAMING LMFAO')
        await message.channel.send ('STAY FOCUSED DONT BLINK')
        await message.channel.send ('DONT GHOST CHAT NOW')
        await message.channel.send ('LOL GET ON UR MAIN HOP OF THE ALT WEAK FUCK')
        await message.channel.send ('YOU KNOW WHEN YOU FALL ASLEEP UR MY GOON RIGHT?')
        await message.channel.send ('UR ASS SON')
        await message.channel.send ('TROLL ASS TWINK')
        await message.channel.send ('LOL YOU LIKE FUCKING TRANNIES')
        await message.channel.send ('WEIRDO')
        await message.channel.send ('GO JERK OFF TO A TRANNY AND THEN PACK ME SON')
        await message.channel.send ('KEEP UP SON')
        await message.channel.send ('UR MY GOON NOW LMFAO')
        await message.channel.send ('HES SCARED RN LMFAO')
        await message.channel.send ('L')
        await message.channel.send ('O')
        await message.channel.send ('O')
        await message.channel.send ('O')
        await message.channel.send ('U')
        await message.channel.send ('SUCK')
        await message.channel.send ('OL')
        await message.channel.send ('L')
        await message.channel.send ('OLO')
        await message.channel.send ('LO')
        await message.channel.send ('O')
        await message.channel.send ('LOLOLO')
        await message.channel.send ('SON STOP SLEEPING AND FOCUS ON ME')
        await message.channel.send ('DID UR MOM WALK IN?')
        await message.channel.send ('UR MY GOON NOW LMFAO')
        await message.channel.send ('HES SCARED RN LMFAO')
        await message.channel.send ('L')
        await message.channel.send ('O')
        await message.channel.send ('O')
        await message.channel.send ('O')
        await message.channel.send ('U')
        await message.channel.send ('SUCK')
        await message.channel.send ('OL')
        await message.channel.send ('L')
        await message.channel.send ('OLO')
        await message.channel.send ('LO')
        await message.channel.send ('O')
        await message.channel.send ('LOLOLO')
        await message.channel.send ('SON STOP SLEEPING AND FOCUS ON ME')
        await message.channel.send ('LOLOL DONT RUN FROM ME')
        await message.channel.send ('U SUCK')
        await message.channel.send ('LOLLLOOLOLOLOLL')
        await message.channel.send ('WHY IS THIS KID SO ASS AT PRESSURING WTF')
        await message.channel.send ('THIS WEAK BITCH LMFAO')
        await message.channel.send ('LAME ASS BOY NEEDS HIS REST')
        await message.channel.send ('LMAO')
        await message.channel.send ('FOCUS ON PRESSURING AND PACKING WEAK BOY CANT MULTI TASK')
        await message.channel.send ('U SUCK TWINK')
        await message.channel.send ('JUST STFU ADMIT U GOT PACKED BOZO')



client.run(token, bot=False)
